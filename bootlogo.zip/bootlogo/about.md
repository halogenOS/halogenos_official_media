**Creator:** [sewer56lol](//github.com/sewer56lol)<br />
**Name:** Cutting Edge Flat Halo (S) Slim Bootlogo<br />
**Made using:** [Adobe Phototoshoppu!](//www.adobe.com/uk/downloads.html)<br />
**Resolution:** 1920x1080 (Original)<br />
**File format:** PNG
